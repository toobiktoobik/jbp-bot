const { Client, GatewayIntentBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages]
});

let events = {}; // Stockage des événements en mémoire

// API pour créer un événement depuis l'onglet Officier
app.post('/api/create-event', async (req, res) => {
    const { title, type, date, details, channelId } = req.body;
    const eventId = Date.now().toString();

    events[eventId] = { id: eventId, title, type, date, details, participants: [] };

    try {
        const channel = await client.channels.fetch(channelId);
        
        const embed = new EmbedBuilder()
            .setTitle(`📢 NOUVEL ÉVÉNEMENT : ${title}`)
            .setDescription(`**Type :** ${type}\n**Date :** ${date}\n**Détails :** ${details}`)
            .setColor(type.includes('PvE') ? 0x990000 : 0xc69214);

        const buttons = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`join_${eventId}_Tank`).setLabel('🛡️ Tank').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId(`join_${eventId}_Heal`).setLabel('🧪 Heal').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId(`join_${eventId}_DPS`).setLabel('⚔️ DPS').setStyle(ButtonStyle.Danger),
            new ButtonBuilder().setCustomId(`leave_${eventId}`).setLabel('❌ Désinscription').setStyle(ButtonStyle.Secondary)
        );

        await channel.send({ embeds: [embed], components: [buttons] });
        res.json({ success: true, event: events[eventId] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Erreur lors de l'envoi sur Discord" });
    }
});

// API pour récupérer les événements sur le site
app.get('/api/events', (req, res) => {
    res.json(Object.values(events));
});

// Interactions avec les boutons Discord
client.on('interactionCreate', async interaction => {
    if (!interaction.isButton()) return;

    const [action, eventId, role] = interaction.customId.split('_');
    const evt = events[eventId];
    if (!evt) return interaction.reply({ content: "Événement expiré ou introuvable.", ephemeral: true });

    const username = interaction.member.displayName;

    if (action === 'join') {
        evt.participants = evt.participants.filter(p => p.username !== username);
        evt.participants.push({ username, role });
        await interaction.reply({ content: `✅ Inscrit(e) en **${role}** !`, ephemeral: true });
    } else if (action === 'leave') {
        evt.participants = evt.participants.filter(p => p.username !== username);
        await interaction.reply({ content: `❌ Inscription retirée.`, ephemeral: true });
    }
});

// Utilisation de la variable d'environnement pour la sécurité
client.login(process.env.DISCORD_TOKEN);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Serveur démarré sur le port ${PORT}`));